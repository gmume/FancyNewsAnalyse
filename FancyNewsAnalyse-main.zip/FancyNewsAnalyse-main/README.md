# FancyNewsAnalyse
COLAB sprint 2
